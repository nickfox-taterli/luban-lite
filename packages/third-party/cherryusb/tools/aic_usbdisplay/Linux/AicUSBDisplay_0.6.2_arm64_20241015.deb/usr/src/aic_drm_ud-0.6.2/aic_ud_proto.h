/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * Copyright (C) 2024 ArtInChip Technology Co., Ltd.
 *
 * Authors: matteo <duanmt@artinchip.com>
 */

#ifndef __AIC_USB_DISPLAY_PROTOCOL_H__
#define __AIC_USB_DISPLAY_PROTOCOL_H__

#define VENDOR_CMD0_GET_PARAMETER   0

#define DISP_MAX_HEIGHT         2048
#define DISP_MAX_WIDTH          2048

#define FRAME_USB_FRAG_HEAD     0x01
#define FRAME_USB_FRAG_END      0x04

#define FRAME_CMD_INDEPENDENT_MODE
#define FRAME_START_MAGIC       (0xA1C62B00 | FRAME_USB_FRAG_HEAD)
#define FRAME_END_MAGIC         (0xA1C62B00 | FRAME_USB_FRAG_END)

struct frame_head {
	u32 s_magic;
	u32 length;
	u16 reserve1;
	u16 media_format;
	u32 reserve2;
	u32 e_magic;
};

#endif /* __AIC_USB_DISPLAY_PROTOCOL_H__ */
