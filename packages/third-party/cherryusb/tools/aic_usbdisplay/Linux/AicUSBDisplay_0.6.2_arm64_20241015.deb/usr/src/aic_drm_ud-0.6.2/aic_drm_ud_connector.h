/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * Copyright (C) 2024 ArtInChip Technology Co., Ltd.
 *
 * Authors: matteo <duanmt@artinchip.com>
 */

#ifndef __AIC_DRM_UD_CONNECTOR_H__
#define __AIC_DRM_UD_CONNECTOR_H__

#include <drm/drm_crtc.h>

struct edid;

struct aic_ud_drm_con {
	struct drm_connector connector;
	struct edid *edid;
	struct urb urb_in;
	struct urb urb_out;
	struct completion complete;
};

#endif //__AIC_DRM_UD_CONNECTOR_H__
