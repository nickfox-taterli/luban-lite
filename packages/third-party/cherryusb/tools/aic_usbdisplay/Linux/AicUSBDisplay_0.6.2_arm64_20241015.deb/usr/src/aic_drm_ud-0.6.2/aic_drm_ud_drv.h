/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * Copyright (C) 2024 ArtInChip Technology Co., Ltd.
 *
 * Authors: matteo <duanmt@artinchip.com>
 */

#ifndef __AIC_DRM_UD_DRV_H__
#define __AIC_DRM_UD_DRV_H__

#include <linux/mm_types.h>
#include <linux/usb.h>

#include <drm/drm_device.h>
#include <drm/drm_framebuffer.h>
#include <drm/drm_gem.h>
#include <drm/drm_simple_kms_helper.h>

#include "video/artinchip_drm.h"
#include "aic_ud_proto.h"

struct drm_mode_create_dumb;

#define DRIVER_NAME		"aic-ud"
#define DRIVER_DESC		"ArtInChip"
#define DRIVER_DATE		"20240520"

#define DRIVER_MAJOR		0
#define DRIVER_MINOR		0
#define DRIVER_PATCHLEVEL	1

#define GET_URB_TIMEOUT		HZ
#define FREE_URB_TIMEOUT	(HZ * 2)

#define MAX_TRANSFER		(PAGE_SIZE * 64)
#define MAX_SHMEM_NUM		16

struct aic_ud_dev;

struct urb_node {
	struct list_head entry;
	struct aic_ud_dev *dev;
	struct delayed_work release_urb_work;
	struct urb *urb;
};

struct urb_list {
	struct list_head list;
	spinlock_t lock;
	struct semaphore limit_sem;
	int available;
	int count;
	size_t size;
};

struct aic_ud_dev {
	struct drm_device drm;
	struct device *dev;
	struct device *dmadev;
	struct usb_device *udev;

	struct drm_gem_object *fb_obj[2];
	struct aic_ud_gem_info fb_info[2];
	int                    cur_fb_id;

	struct drm_simple_display_pipe display_pipe;

	int pixel_limit;
	int stride;
	int fb_size;
	int authenticated;
	struct aic_ud_dev_para dev_para;
	struct aic_ud_drm_con *ud_con;

	struct urb_list urbs;

	bool render_is_online;
	struct drm_file *dfile;
	struct drm_gem_shmem_object *shmem[MAX_SHMEM_NUM];
	u32    shmem_cnt;

	struct completion wait_update_start;
	struct completion wait_update_done;
	struct mutex send_lock;
};

#define to_aic_ud(x) container_of(x, struct aic_ud_dev, drm)

int aic_ud_modeset_init(struct drm_device *dev);
int aic_ud_modeset_free(struct drm_device *dev);
struct drm_connector *aic_ud_connector_init(struct drm_device *dev);

struct urb *aic_ud_get_urb(struct drm_device *dev);
int aic_ud_submit_urb(struct drm_device *dev, struct urb *urb, size_t len);
void aic_ud_urb_completion(struct urb *urb);

int aic_ud_init(struct aic_ud_dev *ud);

int aic_ud_drop_usb(struct drm_device *dev);

int aic_ud_get_dev_para(struct aic_ud_dev *ud);

int aic_ud_send_frame(struct aic_ud_dev *ud, void *buf, u32 size);

int aic_ud_ioctl_gem_create(struct drm_device *dev, void *data,
			    struct drm_file *file_priv);
int aic_ud_ioctl_gem_destroy(struct drm_device *dev, void *data,
			     struct drm_file *file_priv);
int aic_ud_ioctl_wait_update(struct drm_device *dev, void *data,
			     struct drm_file *file_priv);
int aic_ud_ioctl_update_done(struct drm_device *dev, void *data,
			     struct drm_file *file_priv);
int aic_ud_ioctl_render_done(struct drm_device *dev, void *data,
			     struct drm_file *file_priv);
int aic_ud_ioctl_send_data(struct drm_device *dev, void *data,
			   struct drm_file *file_priv);
int aic_ud_ioctl_recv_data(struct drm_device *dev, void *data,
			   struct drm_file *file_priv);
int aic_ud_ioctl_auth_pass(struct drm_device *dev, void *data,
			   struct drm_file *file_priv);
#endif
