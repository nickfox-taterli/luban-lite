// SPDX-License-Identifier: GPL-2.0-only
/*
 * Copyright (C) 2024 ArtInChip Technology Co., Ltd.
 *
 * Authors: matteo <duanmt@artinchip.com>
 */

#include <linux/version.h>
#include <linux/completion.h>
#include <linux/dma-buf.h>
#if (LINUX_VERSION_CODE > KERNEL_VERSION(5, 17, 0))
#include <linux/iosys-map.h>
#elif (LINUX_VERSION_CODE > KERNEL_VERSION(5, 11, 0))
#include <linux/dma-buf-map.h>
#endif

#include <drm/drm_drv.h>
#include <drm/drm_atomic_helper.h>
#include <drm/drm_crtc_helper.h>
#include <drm/drm_damage_helper.h>
#include <drm/drm_fourcc.h>
#include <drm/drm_gem_framebuffer_helper.h>
#include <drm/drm_gem_shmem_helper.h>
#include <drm/drm_modeset_helper_vtables.h>
#include <drm/drm_vblank.h>

#include "aic_drm_ud_drv.h"

MODULE_IMPORT_NS(DMA_BUF);

static void aic_ud_vunmap_one_shmem(struct aic_ud_dev *ud,
				    struct drm_gem_shmem_object *shmem)
{
#if (LINUX_VERSION_CODE > KERNEL_VERSION(5, 17, 0))
	struct iosys_map map = {0};
#elif (LINUX_VERSION_CODE > KERNEL_VERSION(5, 11, 0))
	struct dma_buf_map map = {0};
#endif
	if (!shmem->vmap_use_count)
		return;

	DRM_DEBUG("vunmap shmem %#lx (%d)\n", (long)shmem, shmem->vmap_use_count);
	mutex_lock(&ud->send_lock);
	if (shmem->vaddr) {
#if (LINUX_VERSION_CODE > KERNEL_VERSION(5, 11, 0))
		map.vaddr = shmem->vaddr;
		drm_gem_shmem_vunmap(shmem, &map);
#else
		drm_gem_shmem_vunmap(&shmem->base, shmem->vaddr);
#endif
	}
	mutex_unlock(&ud->send_lock);
}

static void aic_ud_vunmap_all_shmem(struct aic_ud_dev *ud)
{
	int i;

	for (i = 0; i < MAX_SHMEM_NUM; i++) {
		if (ud->shmem[i]) {
			aic_ud_vunmap_one_shmem(ud, ud->shmem[i]);
			ud->shmem_cnt--;
			ud->shmem[i] = NULL;
		}
	}
}

int aic_ud_ioctl_wait_update(struct drm_device *dev, void *data,
			     struct drm_file *file_priv)
{
	struct aic_ud_dev *ud = to_aic_ud(dev);
	int ret = 0, idx, fb_id = ud->cur_fb_id;
	struct aic_ud_gem_info *info = &ud->fb_info[fb_id];

	if (!drm_dev_enter(dev, &idx)) {
		aic_ud_vunmap_all_shmem(ud);
		return -ENODEV;
	}

	if (!ud->render_is_online)
		ud->render_is_online = true;

	/* Wait for the next handle_damage event */
	if (!wait_for_completion_timeout(&ud->wait_update_start, msecs_to_jiffies(1000))) {
		ret = -EAGAIN;
		goto out;
	}

	if (ud->fb_obj[fb_id] && !info->handle) {
		drm_gem_handle_create(file_priv, ud->fb_obj[fb_id], &info->handle);
		ud->dfile = file_priv;
		DRM_DEBUG("Create handle %d\n", info->handle);
	}

	memcpy(data, info, sizeof(struct aic_ud_gem_info));

out:
	drm_dev_exit(idx);
	return ret;
}

int aic_ud_ioctl_update_done(struct drm_device *dev, void *data,
			     struct drm_file *file_priv)
{
	struct aic_ud_dev *ud = to_aic_ud(dev);
	int idx;

	// DRM_INFO("%s() - Update done\n", __func__);
	complete(&ud->wait_update_done);

	if (!drm_dev_enter(dev, &idx)) {
		aic_ud_vunmap_all_shmem(to_aic_ud(dev));
		return -ENODEV;
	}

	drm_dev_exit(idx);
	return 0;
}

int aic_ud_ioctl_render_done(struct drm_device *dev, void *data,
			     struct drm_file *file_priv)
{
	struct aic_ud_gem_info *info = data;
	struct drm_gem_object *obj = NULL;
	struct drm_gem_shmem_object *shmem = NULL;
	struct aic_ud_dev *ud = to_aic_ud(dev);
#if (LINUX_VERSION_CODE > KERNEL_VERSION(5, 17, 0))
	struct iosys_map map = {0};
#elif (LINUX_VERSION_CODE > KERNEL_VERSION(5, 11, 0))
	struct dma_buf_map map = {0};
#endif
	int ret = 0, idx;

	if (!ud->render_is_online) {
		DRM_INFO("%s() - Maybe render exit!\n", __func__);
		return -EBADF;
	}

	if (!drm_dev_enter(dev, &idx)) {
		aic_ud_vunmap_all_shmem(to_aic_ud(dev));
		return -ENODEV;
	}

	DRM_DEBUG("%s() - Render done\n", __func__);

	obj = drm_gem_object_lookup(file_priv, info->handle);
	if (!obj) {
		DRM_DEV_ERROR(dev->dev, "Failed to find GEM obj by handle %d\n", info->handle);
		drm_dev_exit(idx);
		return -EINVAL;
	}
	mutex_lock(&ud->send_lock);

	shmem = to_drm_gem_shmem_obj(obj);
	if (!shmem->vaddr) {
#if (LINUX_VERSION_CODE > KERNEL_VERSION(5, 11, 0))
		if (drm_gem_shmem_vmap(shmem, &map)) {
			DRM_DEV_ERROR(dev->dev, "Failed to vmap %d\n", info->handle);
			drm_gem_object_put(obj);
			drm_dev_exit(idx);
			return -EINVAL;
		}
#else
		shmem->vaddr = drm_gem_shmem_vmap(obj);
#endif
	}

	aic_ud_send_frame(to_aic_ud(dev), shmem->vaddr, info->size);

	drm_gem_object_put(obj);
	mutex_unlock(&ud->send_lock);

	drm_dev_exit(idx);
	DRM_DEBUG("Send out %d data by handle %d\n", info->size, info->handle);
	return ret;
}

int aic_ud_ioctl_gem_create(struct drm_device *dev, void *data,
			    struct drm_file *file_priv)
{
	struct aic_ud_gem_info *info = data;
	struct drm_gem_shmem_object *shmem = NULL;
	struct aic_ud_dev *ud = to_aic_ud(dev);
	int ret = 0, idx;

	if (ud->shmem_cnt >= MAX_SHMEM_NUM) {
		DRM_ERROR("Exceed the max number of shmem!\n");
		return -ENOMEM;
	}

	if (!drm_dev_enter(dev, &idx)) {
		aic_ud_vunmap_all_shmem(to_aic_ud(dev));
		return -ENODEV;
	}

	shmem = drm_gem_shmem_create(dev, info->size);
	if (IS_ERR(shmem)) {
		ret = PTR_ERR(shmem);
		goto out;
	}

	ret = drm_gem_handle_create(file_priv, &shmem->base, &info->handle);
	drm_gem_object_put(&shmem->base);
	if (ret)
		goto out;

	info->offset = drm_vma_node_offset_addr(&shmem->base.vma_node);
	DRM_DEBUG("%s() - shmem obj: %#lx (%d), handle: %d\n", __func__,
		  (long)shmem, shmem->vmap_use_count, info->handle);

	ud->shmem[ud->shmem_cnt++] = shmem;
out:
	drm_dev_exit(idx);
	return ret;
}

static int aic_ud_free_prev_fb(struct aic_ud_dev *ud, int fb_id)
{
	if (!ud->fb_obj[fb_id])
		return 0;

	drm_gem_free_mmap_offset(ud->fb_obj[fb_id]);
	if (ud->dfile)
		drm_gem_handle_delete(ud->dfile, ud->fb_info[fb_id].handle);

	ud->dfile = NULL;
	ud->fb_obj[fb_id] = NULL;
	ud->fb_info[fb_id].handle = 0;
	return 0;
}

int aic_ud_ioctl_gem_destroy(struct drm_device *dev, void *data,
			     struct drm_file *file_priv)
{
	struct drm_gem_shmem_object *shmem = NULL;
	struct aic_ud_dev *ud = to_aic_ud(dev);
	struct aic_ud_gem_info *info = data;
	struct drm_gem_object *obj = NULL;

	obj = drm_gem_object_lookup(file_priv, info->handle);
	if (unlikely(!obj)) {
		DRM_ERROR("Failed to find GEM obj by handle %d\n", info->handle);
		return -1;
	}

	shmem = to_drm_gem_shmem_obj(obj);
	DRM_DEBUG("%s() - shmem obj: %#lx (%d), handle: %d\n", __func__,
		  (long)shmem, shmem->vmap_use_count, info->handle);
	aic_ud_vunmap_one_shmem(ud, shmem);
	ud->shmem_cnt--;

#if (LINUX_VERSION_CODE > KERNEL_VERSION(5, 11, 0))
	drm_gem_shmem_free(shmem);
#else
	drm_gem_shmem_free_object(obj);
#endif
	if (ud->render_is_online) {
		ud->render_is_online = false;
		aic_ud_free_prev_fb(ud, 0);
		aic_ud_free_prev_fb(ud, 1);
	}

	return 0;
}

static int aic_ud_record_cur_fb(struct aic_ud_dev *ud, struct drm_gem_object *obj)
{
	struct aic_ud_gem_info *info = NULL;
	int ret = 0, fb_id = ud->cur_fb_id;

	if (ud->fb_obj[fb_id] == obj) {
		ud->fb_info[fb_id].size = ud->fb_size;
		return 0; /* It's already recorded */
	}

	if (ud->fb_obj[!fb_id] == obj) {
		ud->fb_info[!fb_id].size = ud->fb_size;
		ud->cur_fb_id = !ud->cur_fb_id;
		return 0; /* Switch to another FB object */
	}

	if (obj->import_attach)
		DRM_INFO("FB obj: %#lx, dma_buf: %#lx, import: %#lx (dma %#lx), size: %#lx / %#x\n",
			 (long)obj, (long)obj->dma_buf, (long)obj->import_attach, (long)obj->import_attach->dmabuf,
			 (long)obj->size, ud->fb_size);

	else
		DRM_INFO("FB obj: %#lx, dma_buf: %#lx, import: %#lx, size: %#lx / %#x\n",
			 (long)obj, (long)obj->dma_buf, (long)obj->import_attach,
			 (long)obj->size, ud->fb_size);

	if (!ud->fb_obj[fb_id]) {
		/* The current object is empty */
		info = &ud->fb_info[fb_id];
	} else if (!ud->fb_obj[!fb_id]) {
		/* The other object is empty */
		fb_id = !fb_id;
		info = &ud->fb_info[fb_id];
	} else {
		/* Release one object space */
		fb_id = !fb_id;
		aic_ud_free_prev_fb(ud, fb_id);
		info = &ud->fb_info[fb_id];
	}
	ud->fb_obj[fb_id] = obj;
	ud->cur_fb_id = fb_id;

	if (obj->import_attach && !obj->dma_buf)
		obj->dma_buf = obj->import_attach->dmabuf;

	/* Make it mmapable */
	ret = drm_gem_create_mmap_offset(obj);
	if (ret) {
		dev_err(obj->dev->dev, "Could not allocate mmap offset\n");
		return -1;
	}
	info->offset = drm_vma_node_offset_addr(&obj->vma_node);
	info->size = AIC_UD_FB_IS_CHANGED; /* Notify userspace do mmap() */
	info->handle = 0; /* Create it in aic_ud_ioctl_wait_update() later */
	DRM_INFO("Record to FB obj %d: %#lx, size: %ld, offset: %#lx\n", fb_id,
		 (long)obj, (long)obj->size, (long)info->offset);

	return 0;
}

static int aic_ud_handle_damage(struct drm_framebuffer *fb, int x, int y,
				int width, int height)
{
	struct drm_device *dev = fb->dev;
	struct aic_ud_dev *ud = to_aic_ud(dev);
	struct dma_buf_attachment *import_attach = fb->obj[0]->import_attach;
	int ret, tmp_ret;
	void *vaddr = NULL;
#if (LINUX_VERSION_CODE > KERNEL_VERSION(5, 17, 0))
	struct iosys_map map = {0};
#elif (LINUX_VERSION_CODE > KERNEL_VERSION(5, 11, 0))
	struct dma_buf_map map = {0};
#endif

	if (ud->dev_para.media_format == PIXEL_ENCODE_JPEG ||
	    ud->dev_para.media_format == PIXEL_ENCODE_H264) {
		if (!ud->render_is_online || !ud->authenticated)
			return 0;

		aic_ud_record_cur_fb(ud, fb->obj[0]);

		complete(&ud->wait_update_start);

		if (!wait_for_completion_timeout(&ud->wait_update_done,
						 msecs_to_jiffies(500))) {
			DRM_INFO("Update-done timeout! Maybe render is offline\n");
			ud->render_is_online = false;
		}

		return 0;
	}

	if (import_attach) {
		ret = dma_buf_begin_cpu_access(import_attach->dmabuf,
					       DMA_FROM_DEVICE);
		if (ret)
			return ret;
	}

#if (LINUX_VERSION_CODE > KERNEL_VERSION(6, 2, 0))
	drm_gem_vmap_unlocked(fb->obj[0], &map);
	vaddr = map.vaddr;
#elif (LINUX_VERSION_CODE > KERNEL_VERSION(5, 11, 0))
	drm_gem_shmem_vmap(to_drm_gem_shmem_obj(fb->obj[0]), &map);
	vaddr = map.vaddr;
#else
	vaddr = drm_gem_shmem_vmap(fb->obj[0]);
#endif
	if (IS_ERR(vaddr)) {
		DRM_ERROR("failed to vmap fb\n");
		goto out_dma_buf_end_cpu_access;
	}

	aic_ud_send_frame(to_aic_ud(dev), vaddr, ud->fb_size);
	if (vaddr) {
#if (LINUX_VERSION_CODE > KERNEL_VERSION(6, 2, 0))
		drm_gem_vunmap_unlocked(fb->obj[0], &map);
#elif (LINUX_VERSION_CODE > KERNEL_VERSION(5, 11, 0))
		drm_gem_shmem_vunmap(to_drm_gem_shmem_obj(fb->obj[0]), &map);
#else
		drm_gem_shmem_vunmap(fb->obj[0], vaddr);
#endif
	}

out_dma_buf_end_cpu_access:
	if (import_attach) {
		tmp_ret = dma_buf_end_cpu_access(import_attach->dmabuf,
						 DMA_FROM_DEVICE);
		if (tmp_ret && !ret)
			ret = tmp_ret; /* only update ret if not set yet */
	}

	return ret;
}

static const u32 aic_ud_pipe_formats[] = {
	DRM_FORMAT_XRGB8888,
	DRM_FORMAT_RGB565,
};

static enum drm_mode_status
aic_ud_pipe_mode_valid(struct drm_simple_display_pipe *pipe,
		       const struct drm_display_mode *mode)
{
	return MODE_OK;
}

static void aic_ud_pipe_enable(struct drm_simple_display_pipe *pipe,
			       struct drm_crtc_state *crtc_state,
			       struct drm_plane_state *plane_state)
{
	struct drm_framebuffer *fb = plane_state->fb;

	aic_ud_handle_damage(fb, 0, 0, fb->width, fb->height);
}

static void aic_ud_pipe_update(struct drm_simple_display_pipe *pipe,
			       struct drm_plane_state *old_plane_state)
{
	struct drm_plane_state *state = pipe->plane.state;
	struct drm_device *drm = pipe->crtc.dev;
	struct drm_framebuffer *fb = state->fb;
	struct drm_rect rect;
	int idx;

	if (!fb)
		return;

	if (!drm_dev_enter(drm, &idx)) {
		aic_ud_vunmap_all_shmem(to_aic_ud(drm));
		return;
	}

	if (drm_atomic_helper_damage_merged(old_plane_state, state, &rect))
		aic_ud_handle_damage(fb, rect.x1, rect.y1, rect.x2 - rect.x1,
				     rect.y2 - rect.y1);

	drm_dev_exit(idx);
}

static const
struct drm_simple_display_pipe_funcs aic_ud_pipe_funcs = {
	.mode_valid = aic_ud_pipe_mode_valid,
	.enable = aic_ud_pipe_enable,
	.update = aic_ud_pipe_update,
#if (LINUX_VERSION_CODE < KERNEL_VERSION(5, 11, 0))
	.prepare_fb = drm_gem_fb_simple_display_pipe_prepare_fb,
#endif
};

/*
 * Modesetting
 */

static const struct drm_mode_config_funcs aic_ud_mode_funcs = {
	.fb_create = drm_gem_fb_create_with_dirty,
	.atomic_check  = drm_atomic_helper_check,
	.atomic_commit = drm_atomic_helper_commit,
};

int aic_ud_modeset_init(struct drm_device *dev)
{
	struct aic_ud_dev *ud = to_aic_ud(dev);
	struct aic_ud_dev_para *para = &ud->dev_para;
	struct drm_connector *connector = NULL;
	int ret = 0;

	if (!para->media_width || !para->media_height) {
		DRM_ERROR("Invalid mode: w %d, h %d\n",
			  para->media_width, para->media_height);
		return -1;
	}

	ret = drmm_mode_config_init(dev);
	if (ret)
		return ret;

	dev->mode_config.min_width = para->media_width;
	dev->mode_config.min_height = para->media_height;

	dev->mode_config.max_width = DISP_MAX_WIDTH;
	dev->mode_config.max_height = DISP_MAX_HEIGHT;

	dev->mode_config.prefer_shadow = 0;
	if (para->media_format == PIXEL_ENCODE_RGB565)
		dev->mode_config.preferred_depth = 16;
	else
		dev->mode_config.preferred_depth = 32;

	ud->fb_size = para->media_width * para->media_height
			* dev->mode_config.preferred_depth / 8;
	drm_info(dev, "Create DRM %s card: w %d, h %d, bpp %d\n",
		 para->media_format ? "ARGB888" : "RGB555",
		 para->media_width, para->media_height,
		 dev->mode_config.preferred_depth);

	dev->mode_config.funcs = &aic_ud_mode_funcs;

	connector = aic_ud_connector_init(dev);
	if (IS_ERR(connector))
		return PTR_ERR(connector);

	ret = drm_simple_display_pipe_init(dev, &ud->display_pipe,
					   &aic_ud_pipe_funcs,
					   aic_ud_pipe_formats,
					   ARRAY_SIZE(aic_ud_pipe_formats),
					   NULL, connector);
	if (ret)
		return ret;

	init_completion(&ud->wait_update_start);
	init_completion(&ud->wait_update_done);
	mutex_init(&ud->send_lock);

	drm_mode_config_reset(dev);
	return 0;
}

int aic_ud_modeset_free(struct drm_device *dev)
{
	struct aic_ud_dev *ud = to_aic_ud(dev);

	aic_ud_vunmap_all_shmem(ud);
	aic_ud_free_prev_fb(ud, 0);
	aic_ud_free_prev_fb(ud, 1);

	ud->render_is_online = false;
	return 0;
}
