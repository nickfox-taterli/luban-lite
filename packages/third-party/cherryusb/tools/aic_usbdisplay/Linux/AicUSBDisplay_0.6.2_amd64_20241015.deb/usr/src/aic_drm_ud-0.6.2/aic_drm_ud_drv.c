// SPDX-License-Identifier: GPL-2.0-only
/*
 * Copyright (C) 2024 ArtInChip Technology Co., Ltd.
 *
 * Authors: matteo <duanmt@artinchip.com>
 */

#include <linux/version.h>
#include <linux/module.h>

#include <drm/drm_crtc_helper.h>
#include <drm/drm_drv.h>
#include <drm/drm_fb_helper.h>
#include <drm/drm_file.h>
#include <drm/drm_gem_shmem_helper.h>
#include <drm/drm_modeset_helper.h>
#include <drm/drm_managed.h>
#include <drm/drm_ioctl.h>
#include <drm/drm_probe_helper.h>
#include <drm/drm_print.h>
#if (LINUX_VERSION_CODE > KERNEL_VERSION(6, 2, 0))
#include <drm/drm_fbdev_generic.h>
#endif

#include "aic_drm_ud_drv.h"

static int aic_ud_usb_suspend(struct usb_interface *interface,
			      pm_message_t message)
{
	struct drm_device *dev = usb_get_intfdata(interface);

	return drm_mode_config_helper_suspend(dev);
}

static int aic_ud_usb_resume(struct usb_interface *interface)
{
	struct drm_device *dev = usb_get_intfdata(interface);

	return drm_mode_config_helper_resume(dev);
}

/*
 * FIXME: Dma-buf sharing requires DMA support by the importing device.
 *        This function is a workaround to make USB devices work as well.
 *        See todo.rst for how to fix the issue in the dma-buf framework.
 */
static struct drm_gem_object *aic_ud_gem_prime_import(struct drm_device *dev,
						      struct dma_buf *dma_buf)
{
	struct aic_ud_dev *ud = to_aic_ud(dev);

	if (!ud->dmadev)
		return ERR_PTR(-ENODEV);

	return drm_gem_prime_import_dev(dev, dma_buf, ud->dmadev);
}

static int aic_ud_ioctl_get_fmt(struct drm_device *dev, void *data,
				struct drm_file *file_priv)
{
	struct aic_ud_dev *ud = to_aic_ud(dev);

	memcpy(data, &ud->dev_para, sizeof(struct aic_ud_dev_para));

	return 0;
}

static const struct drm_ioctl_desc aic_ud_ioctls[] = {
	DRM_IOCTL_DEF_DRV(AIC_UD_GET_FMT, aic_ud_ioctl_get_fmt,
			  DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(AIC_UD_GEM_CREATE, aic_ud_ioctl_gem_create,
			  DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(AIC_UD_GEM_DESTROY, aic_ud_ioctl_gem_destroy,
			  DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(AIC_UD_WAIT_UPDATE, aic_ud_ioctl_wait_update,
			  DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(AIC_UD_UPDATE_DONE, aic_ud_ioctl_update_done,
			  DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(AIC_UD_RENDER_DONE, aic_ud_ioctl_render_done,
			  DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(AIC_UD_SEND_DATA, aic_ud_ioctl_send_data,
			  DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(AIC_UD_RECV_DATA, aic_ud_ioctl_recv_data,
			  DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(AIC_UD_AUTH_PASS, aic_ud_ioctl_auth_pass,
			  DRM_RENDER_ALLOW),
};

#if (LINUX_VERSION_CODE < KERNEL_VERSION(5, 11, 0))
const struct vm_operations_struct aic_gem_vm_ops = {
	.open = drm_gem_vm_open,
	.close = drm_gem_vm_close,
};
#endif

DEFINE_DRM_GEM_FOPS(aic_ud_driver_fops);

static struct drm_driver aic_ud_drm_driver = {
	.driver_features	= DRIVER_ATOMIC | DRIVER_GEM | DRIVER_MODESET,

	/* GEM hooks */
#if (LINUX_VERSION_CODE < KERNEL_VERSION(5, 11, 0))
	.gem_create_object	= drm_gem_shmem_create_object_cached,
	.gem_vm_ops		= &aic_gem_vm_ops,
#endif

	.ioctls			= aic_ud_ioctls,
	.num_ioctls		= ARRAY_SIZE(aic_ud_ioctls),
	.fops			= &aic_ud_driver_fops,
	DRM_GEM_SHMEM_DRIVER_OPS,
	.gem_prime_import	= aic_ud_gem_prime_import,

	.name	= DRIVER_NAME,
	.desc	= DRIVER_DESC,
	.date	= DRIVER_DATE,
	.major	= DRIVER_MAJOR,
	.minor	= DRIVER_MINOR,
	.patchlevel = DRIVER_PATCHLEVEL,
};

static struct aic_ud_dev *aic_ud_drv_create(struct usb_interface *interface)
{
	struct usb_device *udev = interface_to_usbdev(interface);
	struct aic_ud_dev *ud = NULL;
	int ret = 0;

	ud = devm_drm_dev_alloc(&interface->dev, &aic_ud_drm_driver,
				struct aic_ud_dev, drm);
	if (IS_ERR(ud))
		return ud;

	ud->udev = udev;

	ret = aic_ud_init(ud);
	if (ret)
		return ERR_PTR(ret);

	usb_set_intfdata(interface, ud);

	return ud;
}

static int aic_ud_usb_probe(struct usb_interface *interface,
			    const struct usb_device_id *id)
{
	int r;
	struct aic_ud_dev *ud = NULL;

	ud = aic_ud_drv_create(interface);
	if (IS_ERR(ud))
		return PTR_ERR(ud);

	r = drm_dev_register(&ud->drm, 0);
	if (r)
		return r;

	DRM_INFO("Init ArtInChip USB Display on minor %d\n",
		 ud->drm.primary->index);

	drm_fbdev_generic_setup(&ud->drm, 0);

	return 0;
}

static void aic_ud_usb_disconnect(struct usb_interface *interface)
{
	struct drm_device *dev = usb_get_intfdata(interface);

	drm_kms_helper_poll_fini(dev);
	aic_ud_drop_usb(dev);
	drm_dev_unplug(dev);
}

static const struct usb_device_id id_table[] = {
	{.idVendor = 0x33C3,
	 .idProduct = 0x0E01,
	 .bInterfaceClass = 0xFF,
	 .bInterfaceSubClass = 0x00,
	 .bInterfaceProtocol = 0x00,
	 .match_flags = USB_DEVICE_ID_MATCH_VENDOR |
			USB_DEVICE_ID_MATCH_INT_CLASS |
			USB_DEVICE_ID_MATCH_INT_SUBCLASS |
			USB_DEVICE_ID_MATCH_INT_PROTOCOL,},
	{},
};
MODULE_DEVICE_TABLE(usb, id_table);

static struct usb_driver aic_ud_driver = {
	.name = DRIVER_NAME,
	.probe = aic_ud_usb_probe,
	.disconnect = aic_ud_usb_disconnect,
	.suspend = aic_ud_usb_suspend,
	.resume = aic_ud_usb_resume,
	.id_table = id_table,
};
module_usb_driver(aic_ud_driver);
MODULE_LICENSE("GPL");
