// SPDX-License-Identifier: GPL-2.0-only
/*
 * Copyright (C) 2024 ArtInChip Technology Co., Ltd.
 *
 * Authors: matteo <duanmt@artinchip.com>
 */

