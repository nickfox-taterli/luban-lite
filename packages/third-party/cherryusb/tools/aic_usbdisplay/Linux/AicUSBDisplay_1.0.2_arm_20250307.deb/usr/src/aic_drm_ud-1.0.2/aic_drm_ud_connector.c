// SPDX-License-Identifier: GPL-2.0-only
/*
 * Copyright (C) 2024 ArtInChip Technology Co., Ltd.
 *
 * Authors: matteo <duanmt@artinchip.com>
 */

#include <linux/random.h>
#include <linux/scatterlist.h>
#include <crypto/akcipher.h>

#include <drm/drm_modeset_helper_vtables.h>
#include <drm/drm_atomic_state_helper.h>
#include <drm/drm_crtc_helper.h>
#include <drm/drm_probe_helper.h>
#include <drm/drm_edid.h>

#include "aic_drm_ud_drv.h"
#include "aic_drm_ud_connector.h"

#define AIC_UD_COMM_DATA_LEN	256
#define AIC_UD_CON_TIMEOUT	msecs_to_jiffies(1000)

#define to_aic_con(c)	container_of(c,	struct aic_ud_drm_con, c)

/* Transfer a block data by bulk EP */
static int aic_ud_transfer(struct aic_ud_dev *ud, const char *data,
			   u32 offset, u32 len)
{
	struct urb *urb = NULL;

	if (unlikely(!len || len > MAX_TRANSFER)) {
		dev_err(&ud->udev->dev, "Invalid data length %d\n", len);
		return -EINVAL;
	}

	urb = aic_ud_get_urb(&ud->drm);
	if (!urb)
		return -1;

	memcpy(urb->transfer_buffer, data + offset, len);
	if (aic_ud_submit_urb(&ud->drm, urb, len))
		return 1; /* regard as once data lost */

	return 0;
}

static int aic_ud_send_frame_head(struct aic_ud_dev *ud, u32 len)
{
	static u32 frame_id;
	struct frame_head head = {0};

	head.s_magic  = FRAME_START_MAGIC;
	head.e_magic  = FRAME_START_MAGIC;
	head.length   = len;
	head.reserve1 = frame_id++;
	head.media_format = ud->dev_para.media_format;

	if (aic_ud_transfer(ud, (char *)&head, 0, sizeof(struct frame_head)))
		return -1;
	else
		return 0;
}

/* Transfer one frame data */
int aic_ud_send_frame(struct aic_ud_dev *ud, void *buf, u32 size)
{
	int pos = 0;

	/* Transfer the whole FrameBuffer */
	if (aic_ud_send_frame_head(ud, size))
		return -1;

	for (pos = 0; pos < size; pos += MAX_TRANSFER) {
		int len = min_t(int, MAX_TRANSFER, size - pos);

		if (aic_ud_transfer(ud, (char *)buf, pos, len))
			return -1;
	}

	return 0;
}

static int aic_ud_get_edid_block(void *data, u8 *buf, unsigned int block,
				 size_t len)
{
	struct aic_ud_dev *ud = data;

	memcpy(buf, ud->dev_para.edid, min_t(size_t, len, AIC_EDID_LENGTH));
	return 0;
}

int aic_ud_get_dev_para(struct aic_ud_dev *ud)
{
	struct aic_ud_dev_para *para = &ud->dev_para;
	int ret = 0;

	ret = usb_control_msg(ud->udev, usb_rcvctrlpipe(ud->udev, 0),
			      VENDOR_CMD0_GET_PARAMETER,
			      USB_DIR_IN | USB_TYPE_VENDOR | USB_RECIP_DEVICE,
			      0, 0,
			      para, sizeof(struct aic_ud_dev_para),
			      USB_CTRL_GET_TIMEOUT);
	if (ret < 0) {
		dev_err(&ud->udev->dev, "Failed to get device parameter\n");
		return ret;
	}

	return ret;
}

static void aic_ud_comm_urb_complete(struct urb *urb)
{
	struct aic_ud_drm_con *ud_con = urb->context;

	complete(&ud_con->complete);
}

int aic_ud_ioctl_send_data(struct drm_device *dev, void *data,
			   struct drm_file *file_priv)
{
	struct aic_ud_dev *ud = to_aic_ud(dev);
	struct aic_ud_drm_con *con = ud->ud_con;
	struct aic_ud_pkt *pkt = data;

	if (unlikely(!pkt->len || pkt->len > AIC_UD_COMM_DATA_LEN)) {
		DRM_ERROR("Invalid data length %d\n", pkt->len);
		return -EINVAL;
	}

	con->urb_out.transfer_buffer_length = pkt->len;
	memcpy(con->urb_out.transfer_buffer, pkt->data, pkt->len);
	if (usb_submit_urb(&con->urb_out, GFP_ATOMIC)) {
		aic_ud_comm_urb_complete(&con->urb_out);
		DRM_ERROR("%s()%d - USB sumbit failed!\n", __func__, __LINE__);
		return -EBUSY;
	}
	if (!wait_for_completion_timeout(&con->complete, AIC_UD_CON_TIMEOUT)) {
		DRM_ERROR("Failed to send the encrypted data!\n");
		return -EBUSY;
	}

	return 0;
}

int aic_ud_ioctl_recv_data(struct drm_device *dev, void *data,
			   struct drm_file *file_priv)
{
	struct aic_ud_dev *ud = to_aic_ud(dev);
	struct aic_ud_drm_con *con = ud->ud_con;
	struct aic_ud_pkt *pkt = data;

	if (usb_submit_urb(&con->urb_in, GFP_ATOMIC)) {
		aic_ud_comm_urb_complete(&con->urb_in);
		DRM_ERROR("%s()%d - USB sumbit failed!\n", __func__, __LINE__);
		return -EBUSY;
	}
	if (!wait_for_completion_timeout(&con->complete, AIC_UD_CON_TIMEOUT)) {
		DRM_ERROR("Failed to receive the plain data!\n");
		return -EBUSY;
	}

	pkt->len = con->urb_in.actual_length;
	memcpy(pkt->data, con->urb_in.transfer_buffer, pkt->len);
	return 0;
}

int aic_ud_ioctl_auth_pass(struct drm_device *dev, void *data,
			   struct drm_file *file_priv)
{
	struct aic_ud_dev *ud = to_aic_ud(dev);

	ud->authenticated = true;
	return 0;
}

static int aic_ud_get_modes(struct drm_connector *connector)
{
	struct aic_ud_drm_con *ud_con =	to_aic_con(connector);

	drm_connector_update_edid_property(connector, ud_con->edid);
	if (ud_con->edid)
		return drm_add_edid_modes(connector, ud_con->edid);
	return 0;
}

static enum drm_mode_status aic_ud_mode_valid(struct drm_connector *connector,
					      struct drm_display_mode *mode)
{
	struct aic_ud_dev *ud = to_aic_ud(connector->dev);

	if (!ud->pixel_limit)
		return MODE_OK;

	if (mode->vdisplay * mode->hdisplay >= ud->pixel_limit)
		return MODE_VIRTUAL_Y;

	return MODE_OK;
}

static enum drm_connector_status aic_ud_detect(struct drm_connector *connector,
					       bool force)
{
	return connector_status_connected;
}

static int aic_ud_comm_urb_init(struct aic_ud_drm_con *ud_con)
{
	struct aic_ud_dev *ud = to_aic_ud(ud_con->connector.dev);
	char *buf = NULL;

	usb_init_urb(&ud_con->urb_in);
	buf = usb_alloc_coherent(ud->udev, AIC_UD_COMM_DATA_LEN, GFP_KERNEL,
				 &ud_con->urb_in.transfer_dma);
	if (!buf)
		return -ENOMEM;
	usb_fill_bulk_urb(&ud_con->urb_in, ud->udev, usb_rcvbulkpipe(ud->udev, 1),
			  buf, AIC_UD_COMM_DATA_LEN, aic_ud_comm_urb_complete, ud_con);
	ud_con->urb_in.transfer_flags |= URB_NO_TRANSFER_DMA_MAP;

	usb_init_urb(&ud_con->urb_out);
	buf = usb_alloc_coherent(ud->udev, AIC_UD_COMM_DATA_LEN, GFP_KERNEL,
				 &ud_con->urb_out.transfer_dma);
	if (!buf)
		return -ENOMEM;
	usb_fill_bulk_urb(&ud_con->urb_out, ud->udev, usb_sndbulkpipe(ud->udev, 1),
			  buf, AIC_UD_COMM_DATA_LEN, aic_ud_comm_urb_complete, ud_con);
	ud_con->urb_out.transfer_flags |= URB_NO_TRANSFER_DMA_MAP;

	return 0;
}

static void aic_ud_comm_urb_free(struct drm_connector *connector)
{
	struct aic_ud_dev *ud = to_aic_ud(connector->dev);
	struct aic_ud_drm_con *ud_con =	to_aic_con(connector);

	usb_free_coherent(ud->udev, AIC_UD_COMM_DATA_LEN,
			  ud_con->urb_in.transfer_buffer,
			  ud_con->urb_in.transfer_dma);
	usb_free_coherent(ud->udev, AIC_UD_COMM_DATA_LEN,
			  ud_con->urb_out.transfer_buffer,
			  ud_con->urb_out.transfer_dma);
}

static void aic_ud_connector_destroy(struct drm_connector *connector)
{
	aic_ud_comm_urb_free(connector);
	drm_connector_cleanup(connector);
	kfree(connector);
}

static const struct drm_connector_helper_funcs aic_ud_con_helper_funcs = {
	.get_modes = aic_ud_get_modes,
	.mode_valid = aic_ud_mode_valid,
};

static const struct drm_connector_funcs aic_ud_con_funcs = {
	.reset = drm_atomic_helper_connector_reset,
	.detect = aic_ud_detect,
	.fill_modes = drm_helper_probe_single_connector_modes,
	.destroy = aic_ud_connector_destroy,
	.atomic_duplicate_state = drm_atomic_helper_connector_duplicate_state,
	.atomic_destroy_state   = drm_atomic_helper_connector_destroy_state,
};

struct drm_connector *aic_ud_connector_init(struct drm_device *dev)
{
	struct aic_ud_dev *ud = to_aic_ud(dev);
	struct aic_ud_drm_con *ud_con;
	struct drm_connector *connector = NULL;

	ud_con = kzalloc(sizeof(struct aic_ud_drm_con), GFP_KERNEL);
	if (!ud_con)
		return ERR_PTR(-ENOMEM);

	connector = &ud_con->connector;
	drm_connector_init(dev, connector, &aic_ud_con_funcs,
			   DRM_MODE_CONNECTOR_VGA);
	drm_connector_helper_add(connector, &aic_ud_con_helper_funcs);

	ud_con->edid = drm_do_get_edid(connector, aic_ud_get_edid_block, ud);
	if (!ud_con->edid)
		goto error;

	if (aic_ud_comm_urb_init(ud_con))
		goto error;

	ud->ud_con = ud_con;
	init_completion(&ud_con->complete);

	connector->polled = DRM_CONNECTOR_POLL_HPD;

	return connector;
error:
	kfree(ud_con);
	return NULL;
}
