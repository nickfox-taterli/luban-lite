// SPDX-License-Identifier: GPL-2.0-only
/*
 * Copyright (C) 2024 ArtInChip Technology Co., Ltd.
 *
 * Authors: matteo <duanmt@artinchip.com>
 */

#include <drm/drm.h>
#include <drm/drm_print.h>
#include <drm/drm_probe_helper.h>

#include "aic_drm_ud_drv.h"

/* -BULK_SIZE as per usb-skeleton. Can we get full page and avoid overhead? */
#define BULK_SIZE 512

#define WRITES_IN_FLIGHT		20
#define MAX_VENDOR_DESCRIPTOR_SIZE	256

static void aic_ud_release_urb_work(struct work_struct *work)
{
	struct urb_node *unode = container_of(work, struct urb_node,
					      release_urb_work.work);

	up(&unode->dev->urbs.limit_sem);
}

void aic_ud_urb_completion(struct urb *urb)
{
	struct urb_node *unode = urb->context;
	struct aic_ud_dev *ud = unode->dev;
	unsigned long flags;

	/* sync/async unlink faults aren't errors */
	if (urb->status) {
		if (!(urb->status == -ENOENT ||
		      urb->status == -ECONNRESET ||
		      urb->status == -ESHUTDOWN)) {
			DRM_ERROR("%s - bulk status error, received: %d\n",
				  __func__, urb->status);
		}
	}

	urb->transfer_buffer_length = ud->urbs.size; /* reset to actual */

	spin_lock_irqsave(&ud->urbs.lock, flags);
	list_add_tail(&unode->entry, &ud->urbs.list);
	ud->urbs.available++;
	spin_unlock_irqrestore(&ud->urbs.lock, flags);

#if 0
	/*
	 * When using fb_defio, we deadlock if up() is called
	 * while another is waiting. So queue to another process.
	 */
	if (fb_defio)
		schedule_delayed_work(&unode->release_urb_work, 0);
	else
#endif
		up(&ud->urbs.limit_sem);
}

static void aic_ud_free_urb_list(struct drm_device *dev)
{
	struct aic_ud_dev *ud = to_aic_ud(dev);
	int count = ud->urbs.count;
	struct list_head *node;
	struct urb_node *unode;
	struct urb *urb;

	DRM_DEBUG("Waiting for completes and freeing all render urbs\n");

	/* keep waiting and freeing, until we've got 'em all */
	while (count--) {
		down(&ud->urbs.limit_sem);

		spin_lock_irq(&ud->urbs.lock);

		node = ud->urbs.list.next; /* have reserved one with sem */
		list_del_init(node);

		spin_unlock_irq(&ud->urbs.lock);

		unode = list_entry(node, struct urb_node, entry);
		urb = unode->urb;

		/* Free each separately allocated piece */
		usb_free_coherent(urb->dev, ud->urbs.size,
				  urb->transfer_buffer, urb->transfer_dma);
		usb_free_urb(urb);
		kfree(node);
	}
	ud->urbs.count = 0;
}

static int aic_ud_alloc_urb_list(struct drm_device *dev, int count, size_t size)
{
	struct aic_ud_dev *ud = to_aic_ud(dev);
	struct urb *urb;
	struct urb_node *unode;
	char *buf;
	size_t wanted_size = count * size;

	spin_lock_init(&ud->urbs.lock);

retry:
	ud->urbs.size = size;
	INIT_LIST_HEAD(&ud->urbs.list);

	sema_init(&ud->urbs.limit_sem, 0);
	ud->urbs.count = 0;
	ud->urbs.available = 0;

	while (ud->urbs.count * size < wanted_size) {
		unode = kzalloc(sizeof(*unode), GFP_KERNEL);
		if (!unode)
			break;
		unode->dev = ud;

		INIT_DELAYED_WORK(&unode->release_urb_work,
				  aic_ud_release_urb_work);

		urb = usb_alloc_urb(0, GFP_KERNEL);
		if (!urb) {
			kfree(unode);
			break;
		}
		unode->urb = urb;

		buf = usb_alloc_coherent(ud->udev, size, GFP_KERNEL,
					 &urb->transfer_dma);
		if (!buf) {
			kfree(unode);
			usb_free_urb(urb);
			if (size > PAGE_SIZE) {
				size /= 2;
				aic_ud_free_urb_list(dev);
				goto retry;
			}
			break;
		}

		/* urb->transfer_buffer_length set to actual before submit */
		usb_fill_bulk_urb(urb, ud->udev, usb_sndbulkpipe(ud->udev, 1),
				  buf, size, aic_ud_urb_completion, unode);
		urb->transfer_flags |= URB_NO_TRANSFER_DMA_MAP;

		list_add_tail(&unode->entry, &ud->urbs.list);

		up(&ud->urbs.limit_sem);
		ud->urbs.count++;
		ud->urbs.available++;
	}

	DRM_DEBUG("allocated %d %d byte urbs\n", ud->urbs.count, (int)size);

	return ud->urbs.count;
}

struct urb *aic_ud_get_urb(struct drm_device *dev)
{
	struct aic_ud_dev *ud = to_aic_ud(dev);
	int ret = 0;
	struct list_head *entry;
	struct urb_node *unode;
	struct urb *urb = NULL;

	/* Wait for an in-flight buffer to complete and get re-queued */
	ret = down_timeout(&ud->urbs.limit_sem, GET_URB_TIMEOUT);
	if (ret) {
		DRM_INFO("wait for urb interrupted: %x available: %d\n",
			 ret, ud->urbs.available);
		goto error;
	}

	spin_lock_irq(&ud->urbs.lock);

	if (WARN_ON(list_empty(&ud->urbs.list)))
		goto error;
	entry = ud->urbs.list.next;
	list_del_init(entry);
	ud->urbs.available--;

	spin_unlock_irq(&ud->urbs.lock);

	unode = list_entry(entry, struct urb_node, entry);
	urb = unode->urb;

error:
	return urb;
}

int aic_ud_submit_urb(struct drm_device *dev, struct urb *urb, size_t len)
{
	struct aic_ud_dev *ud = to_aic_ud(dev);
	int ret = 0;

	if (WARN_ON(len > ud->urbs.size)) {
		ret = -EINVAL;
		goto error;
	}

	urb->transfer_buffer_length = len; /* set to actual payload len */
	ret = usb_submit_urb(urb, GFP_ATOMIC);
error:
	if (ret) {
		aic_ud_urb_completion(urb); /* because no one else will */
		DRM_ERROR("usb_submit_urb error %x\n", ret);
	}
	return ret;
}

#if (LINUX_VERSION_CODE < KERNEL_VERSION(5, 8, 0))
static struct device *usb_intf_get_dma_device(struct usb_interface *intf)
{
	struct usb_device *udev = interface_to_usbdev(intf);
	struct device *dmadev;

	if (!udev->bus)
		return NULL;

	dmadev = get_device(udev->bus->sysdev);
	if (!dmadev || !dmadev->dma_mask) {
		put_device(dmadev);
		return NULL;
	}

	return dmadev;
}
#endif

int aic_ud_init(struct aic_ud_dev *ud)
{
	struct drm_device *dev = &ud->drm;
	int ret = -ENOMEM;

	ud->dmadev = usb_intf_get_dma_device(to_usb_interface(dev->dev));
	if (!ud->dmadev)
		DRM_WARN("buffer sharing not supported");

	if (aic_ud_get_dev_para(ud) < 0)
		return -ENODEV;

	ud->pixel_limit = DISP_MAX_HEIGHT * DISP_MAX_WIDTH;
	if (!aic_ud_alloc_urb_list(dev, WRITES_IN_FLIGHT, MAX_TRANSFER)) {
		DRM_ERROR("aic_ud_alloc_urb_list failed\n");
		goto err;
	}

	ret = aic_ud_modeset_init(dev);
	if (ret)
		goto err;

	drm_kms_helper_poll_init(dev);

	return 0;

err:
	if (ud->urbs.count)
		aic_ud_free_urb_list(dev);
	put_device(ud->dmadev);
	DRM_ERROR("%d\n", ret);
	return ret;
}

int aic_ud_drop_usb(struct drm_device *dev)
{
	struct aic_ud_dev *ud = to_aic_ud(dev);

	aic_ud_free_urb_list(dev);
	aic_ud_modeset_free(dev);
	put_device(ud->dmadev);
	ud->dmadev = NULL;

	return 0;
}
