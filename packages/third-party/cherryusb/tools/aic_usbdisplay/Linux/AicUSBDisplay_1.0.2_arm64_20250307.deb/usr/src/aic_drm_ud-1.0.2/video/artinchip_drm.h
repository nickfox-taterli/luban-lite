/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
/*
 * Definitions for the ArtInChip DRM driver
 *
 * Copyright (C) 2024-2025 ArtInChip Technology Co., Ltd.
 */

#ifndef _UAPI__ARTINCHIP_DRM_H_
#define _UAPI__ARTINCHIP_DRM_H_

#if defined(__cplusplus)
extern "C" {
#endif

#define AIC_EDID_LENGTH		128
#define AIC_UD_DATA_LENGTH	256

#define PIXEL_ENCODE_RGB565     0x00
#define PIXEL_ENCODE_ARGB8888   0x01
#define PIXEL_ENCODE_JPEG       0x10
#define PIXEL_ENCODE_H264       0x11

struct aic_ud_dev_para {
	u16 version;
	u16 chipid;
	u16 media_format;
	u16 media_bus;
	u16 media_mode_num;
	u16 media_width;
	u16 media_height;
	u16 media_fps;
	s8  edid[AIC_EDID_LENGTH];
	s8  reserve[16];
};

struct aic_ud_gem_info {
	u32 handle;
	u32 size;
	u64 offset;
	u32 width;
	u32 height;
	u32 pitch;
	u32 flag;
};

struct aic_ud_pkt {
	u32 len;
	s8  data[AIC_UD_DATA_LENGTH];
};

/* ioctl() command */

#define DRM_AIC_UD_GET_FMT		0x0
#define DRM_AIC_UD_GEM_CREATE	0x1
#define DRM_AIC_UD_GEM_DESTROY	0x2
#define DRM_AIC_UD_WAIT_UPDATE	0x4
#define DRM_AIC_UD_UPDATE_DONE	0x5
#define DRM_AIC_UD_RENDER_DONE	0x6
#define DRM_AIC_UD_SEND_DATA	0x7
#define DRM_AIC_UD_RECV_DATA	0x8
#define DRM_AIC_UD_AUTH_PASS	0x9

#define DRM_IOCTL_AIC_UD_GET_FMT \
		DRM_IOWR(DRM_COMMAND_BASE + DRM_AIC_UD_GET_FMT, \
			 struct aic_ud_dev_para)
#define DRM_IOCTL_AIC_UD_GEM_CREATE \
		DRM_IOWR(DRM_COMMAND_BASE + DRM_AIC_UD_GEM_CREATE, \
			 struct aic_ud_gem_info)
#define DRM_IOCTL_AIC_UD_GEM_DESTROY \
		DRM_IOW(DRM_COMMAND_BASE + DRM_AIC_UD_GEM_DESTROY, \
			struct aic_ud_gem_info)
#define DRM_IOCTL_AIC_UD_WAIT_UPDATE \
		DRM_IOWR(DRM_COMMAND_BASE + DRM_AIC_UD_WAIT_UPDATE, \
			 struct aic_ud_gem_info)
#define DRM_IOCTL_AIC_UD_UPDATE_DONE \
		DRM_IOW(DRM_COMMAND_BASE + DRM_AIC_UD_UPDATE_DONE, \
			struct aic_ud_gem_info)
#define DRM_IOCTL_AIC_UD_RENDER_DONE \
		DRM_IOW(DRM_COMMAND_BASE + DRM_AIC_UD_RENDER_DONE, \
			struct aic_ud_gem_info)
#define DRM_IOCTL_AIC_UD_SEND_DATA \
		DRM_IOW(DRM_COMMAND_BASE + DRM_AIC_UD_SEND_DATA, \
			struct aic_ud_pkt)
#define DRM_IOCTL_AIC_UD_RECV_DATA \
		DRM_IOR(DRM_COMMAND_BASE + DRM_AIC_UD_RECV_DATA, \
			struct aic_ud_pkt)
#define DRM_IOCTL_AIC_UD_AUTH_PASS \
		DRM_IO(DRM_COMMAND_BASE + DRM_AIC_UD_AUTH_PASS)

#define AIC_UD_FB_IS_CHANGED	0xFF

#if defined(__cplusplus)
}
#endif
#endif /* _UAPI__ARTINCHIP_DRM_H_ */
